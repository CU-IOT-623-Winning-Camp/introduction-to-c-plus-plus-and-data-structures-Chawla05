from server import run_local

if __name__ == "__main__":
	run_local()