from bottle import default_app
import server

application = default_app()